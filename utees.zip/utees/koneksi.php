<?php
   $hostname  = "localhost";
   $username  = "root";
   $password  = "root";
   $dbname  = "tebakgambar";
   $db = mysqli_connect($hostname, $username, $password, $dbname);
?>